package app.vitamiin.com.Model;

import java.io.Serializable;

/**
 * Created by Puma on 6/28/2016.
 */
public class ChartInfo implements Serializable {
    public String _f_name="";

    public String _per_day_01="";
    public String _content_unit_01="";
    public String _ppds_01="";

    public String _per_day_02="";
    public String _content_unit_02="";
    public String _ppds_02="";
}
