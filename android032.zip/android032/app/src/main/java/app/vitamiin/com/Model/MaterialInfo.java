package app.vitamiin.com.Model;

import java.io.Serializable;

/**
 * Created by Puma on 6/28/2016.
 */
public class MaterialInfo implements Serializable {
    public int _id;
    public int type;
    public int _good_id;
    public int _material_id;
    public int percentage;
    public String content;
    public String material;
    public String description;
}
