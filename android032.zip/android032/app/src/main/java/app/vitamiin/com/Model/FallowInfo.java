package app.vitamiin.com.Model;

import java.io.Serializable;

/**
 * Created by Puma on 6/28/2016.
 */
public class FallowInfo implements Serializable {
    public String mb_id;
    public String _nick;
    public String imagePath;
}
