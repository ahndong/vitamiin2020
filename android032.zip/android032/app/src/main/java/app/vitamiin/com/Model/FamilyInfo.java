package app.vitamiin.com.Model;

import java.io.Serializable;

/**
 * Created by Puma on 6/28/2016.
 */
public class FamilyInfo implements Serializable {
    public String _nick;
    public String _name;
    public int _sex;
    public String _birth;
    public String _imagePath;

    public double _height;
    public double _weight;
    public String _disease;
    public String _allergy;

    public int _id;
    public String _interest_health;
    public String _prefer_healthfood;
}
