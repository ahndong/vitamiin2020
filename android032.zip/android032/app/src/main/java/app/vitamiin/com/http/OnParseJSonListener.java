package app.vitamiin.com.http;

import org.json.JSONObject;

public interface OnParseJSonListener {
	public void onParseJSon(JSONObject j_source);
}
