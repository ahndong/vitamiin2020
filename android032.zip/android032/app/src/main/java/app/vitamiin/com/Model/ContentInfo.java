package app.vitamiin.com.Model;

import java.io.Serializable;

/**
 * Created by dong8 on 2017-02-21.
 */

public class ContentInfo implements Serializable {
    public String _f_name="";
    public String _per_day;
    public String _content_unit="";
    public String _ppds;

    public int _content_id;
    public String _f_description="";
}
