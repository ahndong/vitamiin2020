package app.vitamiin.com.Model;
import java.io.Serializable;

/**
 * Created by dong8 on 2017-03-21.
 */

public class SharedPref implements Serializable{
    public String m_strUserType="";
    public String m_strUseremail="";
    public String m_strUserid="";
    public String m_strUserPass="";
    public String m_strFcmToken="";
}